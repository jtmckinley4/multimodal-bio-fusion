"""Resolve encoder-swap evidence locations without creating or importing files.

Scoring evidence and validation-selection evidence have different roles. A
returned Newton workspace retains both; neither falls back to desktop records.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


BENCHMARKS = (
    "cov_vac_degradation", "fungal_expression", "ecoli_proteins", "mrna_stability",
)


def historical_originals(code_dir):
    """Retain the existing fungal reference route and the other Phase A roots."""
    code_dir = Path(code_dir)
    folders = {key: (code_dir / "stage4/results/phaseA" / key,) for key in BENCHMARKS}
    folders["fungal_expression"] = (
        code_dir / "stage3/results/fungal_expression", *folders["fungal_expression"],
    )
    return folders


@dataclass(frozen=True)
class SwapResultSet:
    name: str
    root: Path
    originals: dict
    swaps: Path
    selection_originals: dict
    selection_swaps: Path
    saved_report_dirs: tuple
    analysis_dir: Path
    fixed_historical_selection: bool
    imported: bool

    def require_writable_fits(self):
        """Imported fits are immutable; local reports have a separate destination."""
        if self.imported:
            raise ValueError(
                "Imported Newton results are read-only. Use an explicit execution "
                "workspace for new fits; do not fill gaps in the imported cohort."
            )


def resolve_swap_results(code_dir, name="historical", *, workspace=None):
    """Select historical evidence or a returned workspace with its original tree.

    ``workspace`` is the returned package root, containing ``outputs/`` and
    ``historical_results/Code/``. Existence is deliberately not inferred here:
    missing evidence must remain visible to the readers. This function does no IO
    beyond path resolution and never creates directories or substitutes results.
    """
    code_dir = Path(code_dir).resolve()
    results = code_dir / "stage4/results"
    if name == "historical":
        if workspace is not None:
            raise ValueError("Historical results use their maintained paths, not a workspace override.")
        originals = historical_originals(code_dir)
        swaps = results / "phaseB"
        reports = swaps / "analyses/paired-report-v1"
        return SwapResultSet(name, results, originals, swaps, originals, swaps,
                             (reports,), reports, False, False)

    if name != "newton_h100_seeds012":
        raise ValueError(f"Unknown result set: {name!r}")
    root = (Path(workspace) if workspace is not None else results / name).resolve()
    protected = (results / "phaseA", results / "phaseB",
                 code_dir / "stage3/results/fungal_expression")
    for old in protected:
        old = old.resolve()
        if root == old or root in old.parents or old in root.parents:
            raise ValueError(f"Imported workspace overlaps historical evidence: {old}")
    originals = {key: (root / "outputs/phaseA" / key,) for key in BENCHMARKS}
    swaps = root / "outputs/phaseB"
    selection = root / "historical_results/Code"
    producer_reports = swaps / "analyses/paired-report-v1"
    local_reports = root / "local_analyses/paired-report-v1"
    return SwapResultSet(
        name, root, originals, swaps, historical_originals(selection),
        selection / "stage4/results/phaseB", (local_reports, producer_reports),
        local_reports, True, True,
    )
